import os

PROJECT_ROOT_ADDRESS = os.path.expanduser('image/')
OMNIGLOT_RAW_DATA_ADDRESS = os.path.expanduser('dataset/')
