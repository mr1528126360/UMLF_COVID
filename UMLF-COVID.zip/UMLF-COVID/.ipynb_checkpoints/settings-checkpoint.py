import os

PROJECT_ROOT_ADDRESS = os.path.expanduser('/_dongxin/image2/')
#OMNIGLOT_RAW_DATA_ADDRESS = os.path.expanduser('~/datasets/omniglot/')
OMNIGLOT_RAW_DATA_ADDRESS = os.path.expanduser('/_dongxin/yliang-dongxin/MiaoRui/03/dataset/')
#IMAGENET_RAW_DATA_ADDRESS = os.path.expanduser('~/datasets/imagenet/')
#MINI_IMAGENET_RAW_DATA_ADDRESS = os.path.expanduser('~/datasets/mini-imagenet/')
#MINI_IMAGENET_RAW_DATA_ADDRESS = os.path.expanduser('/_dongxin/few shot/Untitled Folder/image/')
